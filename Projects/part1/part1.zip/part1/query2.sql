SELECT COUNT(UserID) FROM User WHERE Location = 'New York' ; 
