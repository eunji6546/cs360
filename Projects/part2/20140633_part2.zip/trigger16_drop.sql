AGMA foreign_keys = ON;
drop trigger trigger16;

