PRAGMA foreign_keys = ON;
drop trigger trigger11;

